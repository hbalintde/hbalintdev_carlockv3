local UI = false
local blur = "MenuMGIn"

function setUI(state)
	if state then
		ESX.TriggerServerCallback("scoreboard:getData", function(playerTable, robberies, factions)
			UI = true
			-- show

			StartScreenEffect(blur, 1, true)
			SetNuiFocusKeepInput(true)
			SetNuiFocus(true, true)
			SendNUIMessage({
				visible = true,
				robberies = robberies,
				players = playerTable,
				factions = factions,
			})
		end)
	else
		SetNuiFocus(false, false)
		UI = false
		SetNuiFocusKeepInput(false)
		StopScreenEffect(blur)

		SendNUIMessage({
			visible = false,
		})
	end
end

RegisterCommand("scoreboard", function(s, a, r)
	setUI(not UI)
end)

RegisterNUICallback("close", function()
	setUI(false)
	UI = false
end)

RegisterKeyMapping("scoreboard", "Scoreboard", "keyboard", Config.OpenKey)

CreateThread(function()
	while true do
	  DisableControlAction(0, 36, true)
	  Wait(0)
	end
  end)
