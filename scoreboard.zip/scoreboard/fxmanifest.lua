-- Resource Metadata
fx_version("cerulean")
game("gta5")
lua54("yes")
author "hbalintdev.exe"
-- Shared
shared_scripts({
	"@es_extended/imports.lua",
	"config.lua",
})

-- Client
client_script("client.lua")

-- Server
server_script("server.lua")

-- web
files({
	"web/dist/**",
	"web/logo.png"
})

ui_page("web/dist/index.html")
