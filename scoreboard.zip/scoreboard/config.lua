Config = {}

Config.OpenKey = "F10"

Config.Factions = {
	["unemployed"] = "Rendfenntartó",
	["romania"] = "Románia",
	["ekorea"] = "Észak-Korea",
	["delkorea"] = "Dél-Korea",
	["brazil"] = "Brazília",
	["izrael"] = "Izrael",
	["argentin"] = "Argentína",
	["india"] = "India",
	["usa"] = "USA",
	["montenegro"] = "Montenegro",
	["nagybritannia"] = "Nagy-Britannia",
	["kina"] = "Kína",
	["romania"] = "Románia",
	["horvat"] = "Horvátország",
	["monaco"] = "Monaco",
	["jamaica"] = "Jamaica",
	["fehero"] = "Fehéroroszország",
	["orosz"] = "Oroszország",
	["albania"] = "Albánia",
	["arab"] = "Arab",
	["sved"] = "Svéd",
	["nigeria"] = "Nigéria",

}
