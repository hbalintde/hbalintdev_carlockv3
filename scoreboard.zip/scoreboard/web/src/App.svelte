<script>
  let visible = false;
  let robberies = [];
  let players = [];
  let factions = [];

  window.addEventListener("message", function (event) {
    let data = event.data;
    if (data.visible !== undefined) {
      visible = data.visible;
    }
    if (data.robberies !== undefined) {
      robberies = data.robberies;
    }
    if (data.players !== undefined) {
      players = data.players;
    }
    if (data.factions !== undefined) {
      factions = data.factions;
    }
  });
  import { fly, scale, slide, fade } from "svelte/transition";

  function onKeyDown(e) {
    console.log(e.keyCode);
    if (e.keyCode == 27) {
      fetch(`https://${GetParentResourceName()}/close`);
    }
  }
</script>

<svelte:head>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
  />
</svelte:head>

{#if visible}
  <div class="w-full h-full flex justify-center items-center">
    <div
      in:fade={{ duration: 100 }}
      out:fade={{ duration: 100 }}
      class="w-1/2 h-2/3 rounded-lg p-2 flex flex-col gap-3 bg-gradient-to-b from-[#000000a6] via-[#000000a6]/90 to-[#000000a6]/0"
    >
      <div class="w-full h-[13%] flex justify-between items-center">
        <div class="h-full p-2 flex items-center w-1/2 gap-1 text-lg uppercase">
          <img class="w-[8vh]" src="logo/logo.png" alt="logo" />
          <span class="text-[#ff0000]">Elemental </span> RolePlay
        </div>
        <div class="w-1/2 h-full flex justify-end">
          <div class="w-full h-full flex gap-1 items-center justify-end pr-2">
            {#each factions as faction}
              <div
                class="bg-white/5 w-fit h-fit p-2 flex justify-between gap-1 rounded-md"
              >
                <div class="">{faction.label}</div>
                -
                <div class="">{faction.count}</div>
              </div>
            {/each}
          </div>
        </div>
      </div>
      <div class="w-full h-fit flex gap-2">
        {#each robberies as robbery}
          <div
            class="w-full flex py-2 items-center transition-all justify-center rounded-md gap-2 hover:scale-[98%] {robbery.active
              ? 'bg-[#ff0000]/30 hover:bg-[#ff0000]/40'
              : 'bg-[#00fc2a]/30 hover:bg-[#00fc2a]/40'}"
          >
            <div class={robbery.active ? "text-[#ff0000]" : "text-[#00fc2a]"}>
              <i class="fa-solid fa-circle-dot" />
            </div>
            {robbery.label}
          </div>
        {/each}
      </div>
      <div class="players-box w-full max-h-[100%] overflow-y-auto">
        {#each players as player}
          <div
            class="bg-white/5 h-fit p-3 w-full hover:bg-white/10 transition-all hover:scale-[98%]"
          >
            <div class="flex w-full justify-between">
              <div class="">{player.name} ({player.id})</div>

              <div class="flex gap-1 items-center">
                {#if player.isAdmin}
                  <div class="text-[#ff0000]">
                    <i class="fa-solid fa-crown" />
                  </div>
                {/if}
                {#if player.isNew}
                  <div class="text-[#00fc2a]">
                    <i class="fa-solid fa-plus" />
                  </div>
                {/if}
                <i class="fa-solid fa-user-large" />
              </div>
            </div>
          </div>
        {/each}
      </div>
    </div>
  </div>
{/if}

<svelte:window on:keydown={onKeyDown} />
