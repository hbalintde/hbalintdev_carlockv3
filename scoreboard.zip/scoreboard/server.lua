
ESX.RegisterServerCallback("scoreboard:getData", function(source, cb)
	local playerTable = {}
	local xPlayers = ESX.GetExtendedPlayers() -- Returns all xPlayers
	local factions = {}
	for k, v in pairs(Config.Factions) do
		table.insert(factions, {
			label = v,
			count = #ESX.GetExtendedPlayers("job", k),
		})
	end
	for _, xPlayer in pairs(xPlayers) do
		table.insert(playerTable, {
			name = GetPlayerName(xPlayer.source),
			isAdmin = (xPlayer.getGroup() ~= "user" and true or false),
			isNew = false,
			id = xPlayer.source,
		})
	end

	cb(playerTable, robberies, factions)
end)
